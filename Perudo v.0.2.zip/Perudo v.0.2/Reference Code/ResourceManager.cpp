#include "ResourceManager.h"

std::map<std::string, std::unique_ptr<sf::Texture>> ResourceManager::textures;